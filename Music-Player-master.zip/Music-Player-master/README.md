<!--
*** Hey there! Thanks for checking this readme
*** If you do love my work, kinda follow me
*** that motivates me a lot :D
*** Thanks again!
-->
<!--
[![Contributors][contributors-shield]][contributors-url]
[![Forks][forks-shield]][forks-url]
[![Stargazers][stars-shield]][stars-url]
[![MIT License][license-shield]][license-url]
-->

<img src="https://firebasestorage.googleapis.com/v0/b/scholar-engine-32b26.appspot.com/o/music%20player.png?alt=media&token=968f522a-9bbc-4531-bc78-91fade2a05b4" align="right"/>

# Mini Music Player [![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://github.com/codeninja02)
> A simple music player app in a few lines of code!

You can listen to music, control player in this app.<br>
This app is designed only for mobiles and not very responsive.

- [VIEW DEMO](https://promuze.netlify.app)

## Social Links

- [INSTAGRAM](https://www.instagram.com/codeninja02/)


